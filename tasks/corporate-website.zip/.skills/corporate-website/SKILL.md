---
name: corporate-website
description: >
  快速搭建现代化企业官网，支持单页滚动、多页路由、AI智能助手、访客留资、留言表单、
  响应式设计、粒子动画、滚动触发动画。技术栈 React + Vite + TypeScript + Tailwind CSS + shadcn/ui。
  当用户提到以下需求时触发：企业官网、公司网站、品牌官网、产品官网、企业门户网站、
  公司介绍网站、企业展示网站、营销落地页、企业官网开发、官网建设、公司主页。
  适用于需要展示企业形象、业务领域、联系方式的B2B和B2C企业。
---

# 企业官网 Skill

## 概述

本技能帮助开发者在30分钟内搭建一个**现代化企业官网**，具备以下核心能力：

| 能力 | 说明 |
|------|------|
| 📄 单页滚动 | Hero → 关于 → 业务 → 联系方式，锚点导航 |
| 🔗 多页路由 | 首页 + 子页面（如合伙人招募、产品详情） |
| 🎨 暗色主题 | 科技感暗色设计 + 粒子动画 + 滚动动画 |
| 📱 响应式 | 移动端汉堡菜单 + 自适应布局 |
| 🤖 AI助手 | 浮动AI聊天窗口（见 website-ai-assistant skill） |
| 📝 留言表单 | Supabase 数据库存储，含 toast 反馈 |
| 🗂️ 业务展示 | 可展开的业务卡片、时间轴、数据看板 |

## 前置条件

- Node.js 18+
- Supabase 项目（可选，用于留言和AI助手）
- 企业Logo、品牌色、文案内容

## 快速开始

### Step 1: 初始化项目

```bash
# 使用 Vite 模板
npm create vite@latest my-website -- --template react-ts
cd my-website

# 安装核心依赖
npm install react-router-dom motion lucide-react sonner
npm install -D tailwindcss@^3.4 postcss autoprefixer

# 初始化 Tailwind
npx tailwindcss init -p
```

### Step 2: 复制配置文件

从 `references/project-config.md` 复制以下文件到项目：
- `tailwind.config.js` — Tailwind 暗色主题配置
- `src/index.css` — 全局样式 + CSS 变量
- `vite.config.ts` — Vite + React + 路径别名
- `src/routes.tsx` — 路由配置

### Step 3: 创建页面组件

从 `references/section-components.md` 复制以下组件：
- `Navbar` — 粘性导航 + 移动端菜单 + 平滑滚动
- `Hero` — 全屏英雄区 + 粒子动画 Canvas
- `About` — 时间轴 + 使命愿景 + 统计数据
- `Business` — 可展开的业务卡片（手风琴效果）
- `Contact` — 留言表单 + Supabase 集成
- `Footer` — 链接 + 联系信息 + ICP备案

### Step 4: 组装首页

从 `references/homepage-template.md` 复制 `HomePage.tsx`，将所有 section 组件串联。

### Step 5: 构建部署

```bash
npm run build
```

构建产物在 `dist/` 目录下，可直接部署到任何静态托管服务（Vercel/Netlify/Cloudflare Pages）。

## 页面结构

```
┌─────────────────────────────────────────┐
│  Navbar（粘性导航，滚动时背景变实）     │
├─────────────────────────────────────────┤
│                                         │
│  Hero（全屏粒子动画 + 标题 + CTA按钮）  │
│                                         │
├─────────────────────────────────────────┤
│  About（企业简介 + 时间轴 + 统计数字）  │
├─────────────────────────────────────────┤
│  Partners（合作伙伴/客户 Logo 墙）      │
├─────────────────────────────────────────┤
│  Business（业务领域，可展开卡片）         │
├─────────────────────────────────────────┤
│  Platform（产品/平台详情，可选）        │
├─────────────────────────────────────────┤
│  ThinkTank/Team（智库/团队，可选）      │
├─────────────────────────────────────────┤
│  Contact（留言表单 + 联系信息地图）      │
├─────────────────────────────────────────┤
│  Footer（链接 + 备案号 + 版权）         │
└─────────────────────────────────────────┘
```

## 定制化指南

### 1. 品牌色替换

编辑 `tailwind.config.js`：

```js
// 将 cyan 替换为企业的品牌色
// 例如绿色主题：
primary: {
  DEFAULT: "#10B981", // emerald-500
  foreground: "#FFFFFF",
},
```

### 2. 内容替换

每个 section 组件顶部都有 **内容配置区**，只需修改文案和数组数据：

```tsx
// src/components/About.tsx
const TIMELINE = [
  { year: "2006", title: "公司成立", desc: "..." },
  // 添加更多节点
];

const STATS = [
  { value: "80+", label: "技术研发团队" },
  // 添加更多数据
];
```

### 3. 添加/删除 Section

在 `HomePage.tsx` 中增删组件：

```tsx
<main>
  <Hero />
  <About />
  {/* <Partners /> // 不需要时注释掉 */}
  <Business />
  {/* 添加新的 section */}
  <MyCustomSection />
  <Contact />
</main>
```

### 4. 添加子页面

1. 在 `src/routes.tsx` 中添加路由
2. 创建 `src/pages/MyPage.tsx`
3. 在 Navbar 中添加导航链接

### 5. Logo 替换

- 将 `public/logo.png` 替换为企业 Logo
- 修改 `Navbar.tsx` 中的 `alt` 文字和企业名称

## 技术架构

```
React 18
├── Vite（构建工具）
├── TypeScript（类型安全）
├── Tailwind CSS v3（样式系统）
├── shadcn/ui（UI组件库）
├── react-router-dom v7（路由）
├── motion/react（动画）
├── lucide-react（图标）
├── sonner（Toast通知）
└── Supabase（可选后端）
    ├── 留言数据表
    ├── Edge Functions（AI助手）
    └── 飞书推送
```

## 动画系统

### 粒子动画（Hero区）

使用 Canvas 2D 绘制连接粒子，模拟星空/科技感背景：
- 随机分布粒子
- 鼠标靠近时粒子相互连接
- 粒子缓慢漂移

### 滚动触发动画

使用 `motion/react` + `useInView`：
- 元素进入视口时淡入上浮
- 统计数字滚动递增
- 时间轴节点依次出现

### 手风琴卡片

使用 `@radix-ui/react-accordion`：
- 点击展开/收起业务详情
- 每次只展开一个
- 平滑高度过渡

## 参考文件

| 文件 | 用途 |
|------|------|
| `references/project-config.md` | package.json、tailwind.config、vite.config、index.css、routes.tsx |
| `references/section-components.md` | Navbar、Hero、About、Business、Contact、Footer 完整代码 |
| `references/homepage-template.md` | HomePage.tsx 组装模板 |
| `references/supabase-integration.md` | 数据库表、Supabase client、留言表单集成 |

## 注意事项

- **shadcn/ui 组件**：使用 `npx shadcn add button card accordion` 安装，不要手写基础组件
- **Tailwind v3 vs v4**：本技能使用 v3（`@tailwind base/components/utilities`），v4 语法不同
- **路由模式**：使用 HashRouter 或 BrowserRouter，根据部署平台选择
- **SEO**：为每个页面添加 `<title>` 和 `<meta>` 描述（使用 react-helmet-async）
- **图片优化**：使用 WebP 格式，懒加载非首屏图片
- **ICP备案**：Footer 中添加备案号，符合中国法规

## 故障排查

| 问题 | 原因 | 解决 |
|------|------|------|
| 构建报错 `@tailwindcss` | 使用了 v4 语法 | 改用 `@tailwind base/components/utilities` |
| 路由刷新404 | 服务器未配置SPA回退 | 使用 HashRouter 或配置 nginx `try_files` |
| 暗色模式不生效 | CSS变量未定义 | 检查 `index.css` 中的 `--background` 等变量 |
| 移动端菜单不关闭 | 点击链接后未调用 `setMobileOpen(false)` | 确保所有导航点击都关闭菜单 |
| 锚点滚动不生效 | 元素id不存在 | 确认 `href="#xxx"` 与 `<section id="xxx">` 匹配 |

## 扩展建议

- **多语言**：接入 i18n（react-i18next），为国际化企业准备
- **CMS集成**：将内容从硬编码改为从 Strapi/Contentful 获取
- **SEO优化**：添加 sitemap.xml、robots.txt、结构化数据
- **性能优化**：启用 vite-plugin-pwa 实现离线访问
- **数据分析**：接入百度统计/Google Analytics
- **表单防垃圾**：添加 reCAPTCHA v3
