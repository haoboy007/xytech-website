# Supabase 集成指南

## 1. 数据库表

### 留言表（messages）

```sql
CREATE TABLE IF NOT EXISTS messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  email TEXT,
  phone TEXT,
  company TEXT,
  message TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 启用 RLS（行级安全）
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

-- 允许匿名用户插入
CREATE POLICY "Allow anonymous insert" ON messages
  FOR INSERT WITH CHECK (true);

-- 允许管理员读取（需要设置认证策略或使用 service_role）
```

### AI对话会话表（ai_chat_sessions）

```sql
CREATE TABLE IF NOT EXISTS ai_chat_sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  source TEXT DEFAULT 'website',
  contact_name TEXT,
  contact_phone TEXT,
  contact_email TEXT,
  contact_company TEXT,
  contact_city TEXT,
  contact_intent TEXT,
  client_ip TEXT,
  client_location TEXT,
  messages JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT NOW()
);

ALTER TABLE ai_chat_sessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Allow anonymous insert" ON ai_chat_sessions
  FOR INSERT WITH CHECK (true);
```

## 2. Supabase Client

```ts
// src/db/supabase.ts
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);
```

环境变量（`.env`）：

```
VITE_SUPABASE_URL=https://xxxx.supabase.co
VITE_SUPABASE_ANON_KEY=eyJ...
```

## 3. Contact 组件集成

将 `Contact.tsx` 中的提交逻辑替换为 Supabase：

```tsx
import { supabase } from "@/db/supabase";

const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  if (!form.name || !form.message) {
    toast.error("请填写必填项");
    return;
  }
  setSubmitting(true);

  const { error } = await supabase.from("messages").insert({
    name: form.name,
    email: form.email,
    phone: form.phone,
    company: form.company,
    message: form.message,
  });

  if (error) {
    toast.error("提交失败，请稍后重试");
    console.error(error);
  } else {
    toast.success("提交成功！我们会尽快与您联系");
    setForm({ name: "", email: "", phone: "", company: "", message: "" });
  }

  setSubmitting(false);
};
```

## 4. 查看留言（管理后台）

```tsx
// src/pages/AdminMessages.tsx
import { useEffect, useState } from "react";
import { supabase } from "@/db/supabase";

export default function AdminMessages() {
  const [messages, setMessages] = useState<any[]>([]);

  useEffect(() => {
    supabase
      .from("messages")
      .select("*")
      .order("created_at", { ascending: false })
      .then(({ data }) => setMessages(data || []));
  }, []);

  return (
    <div className="p-8 max-w-4xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">留言管理</h1>
      <div className="space-y-4">
        {messages.map((msg) => (
          <div key={msg.id} className="border rounded-lg p-4 bg-card">
            <div className="flex justify-between text-sm text-muted-foreground mb-2">
              <span>{msg.name}</span>
              <span>{new Date(msg.created_at).toLocaleString()}</span>
            </div>
            <p className="text-sm">{msg.message}</p>
            <div className="mt-2 text-xs text-muted-foreground">
              {msg.email} · {msg.phone} · {msg.company}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
```

## 5. Edge Function（AI对话 + 推送）

详见 `website-ai-assistant` skill 的参考文件：
- `references/ai-chat-edge-function.md`
- `references/lead-push-edge-function.md`

## 6. 数据分析视图

```sql
-- 每日留言统计
CREATE OR REPLACE VIEW daily_messages AS
SELECT 
  DATE_TRUNC('day', created_at)::date AS date,
  COUNT(*) AS count
FROM messages
GROUP BY DATE_TRUNC('day', created_at)::date
ORDER BY date DESC;

-- 按来源统计（如果有 source 字段）
CREATE OR REPLACE VIEW messages_by_source AS
SELECT 
  COALESCE(source, 'website') AS source,
  COUNT(*) AS count
FROM messages
GROUP BY source
ORDER BY count DESC;
```
