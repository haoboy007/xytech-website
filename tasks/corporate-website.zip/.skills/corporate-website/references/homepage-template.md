# 首页组装模板

## HomePage.tsx

```tsx
// src/pages/HomePage.tsx
import { useEffect, useState } from "react";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Business from "@/components/Business";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

// 可选：添加更多 section
// import Partners from "@/components/Partners";
// import Platform from "@/components/Platform";
// import Team from "@/components/Team";

export default function HomePage() {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 60);
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground grid-bg">
      <Navbar scrolled={scrolled} />
      <main>
        <Hero />
        <About />
        {/* <Partners /> */}
        <Business />
        {/* <Platform /> */}
        {/* <Team /> */}
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
```

## 组件按需加载优化

如果 section 较多，可以使用懒加载优化首屏：

```tsx
import { lazy, Suspense } from "react";

const About = lazy(() => import("@/components/About"));
const Business = lazy(() => import("@/components/Business"));
// ... 其他 section

export default function HomePage() {
  // ...
  return (
    <div>
      <Navbar scrolled={scrolled} />
      <main>
        <Hero />
        <Suspense fallback={<div className="py-20 text-center">加载中...</div>}>
          <About />
          <Business />
          <Contact />
        </Suspense>
      </main>
      <Footer />
    </div>
  );
}
```

## 滚动动画 Hook（可选增强）

```tsx
// src/hooks/useScrollAnimation.ts
import { useEffect, useRef, useState } from "react";

export function useScrollAnimation(threshold = 0.1) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [threshold]);

  return { ref, isVisible };
}
```

使用方式：

```tsx
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

export default function MySection() {
  const { ref, isVisible } = useScrollAnimation();

  return (
    <section
      ref={ref}
      className={`transition-all duration-700 ${
        isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
      }`}
    >
      {/* 内容 */}
    </section>
  );
}
```

## 导航锚点映射

确保 `Navbar` 中的 `href` 与每个 section 的 `id` 一一对应：

| Navbar href | Section id | 组件 |
|-------------|-----------|------|
| `#hero` | `id="hero"` | Hero |
| `#about` | `id="about"` | About |
| `#business` | `id="business"` | Business |
| `#contact` | `id="contact"` | Contact |

## 多页路由导航

如果首页以外的页面也需要导航到首页锚点：

```tsx
// Navbar.tsx 中
const navigate = useNavigate();
const location = useLocation();
const isHome = location.pathname === "/";

const handleNav = (href: string) => {
  if (!isHome) {
    navigate("/" + href);
    setTimeout(() => {
      const el = document.getElementById(href.replace("#", ""));
      if (el) el.scrollIntoView({ behavior: "smooth" });
    }, 150);
  } else {
    scrollTo(href);
  }
};
```
