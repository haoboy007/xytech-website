# Section 组件模板

## 1. Navbar（粘性导航栏）

```tsx
// src/components/Navbar.tsx
import { useState } from "react";
import { Menu, X } from "lucide-react";

const NAV_ITEMS = [
  { label: "首页", href: "#hero" },
  { label: "关于我们", href: "#about" },
  { label: "业务领域", href: "#business" },
  { label: "联系我们", href: "#contact" },
];

interface NavbarProps {
  scrolled: boolean;
}

function scrollTo(href: string) {
  const el = document.getElementById(href.replace("#", ""));
  if (el) el.scrollIntoView({ behavior: "smooth" });
}

export default function Navbar({ scrolled }: NavbarProps) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/90 backdrop-blur-md border-b shadow-sm"
          : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 md:px-8 h-16 flex items-center justify-between">
        {/* Logo */}
        <button onClick={() => scrollTo("#hero")} className="flex items-center gap-2">
          <img src="/logo.png" alt="Logo" className="w-9 h-9 rounded-full object-cover" />
          <span className="font-semibold text-sm tracking-wider">企业名称</span>
        </button>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-8">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.href}
              onClick={() => scrollTo(item.href)}
              className="text-sm text-foreground/70 hover:text-primary transition-colors"
            >
              {item.label}
            </button>
          ))}
        </nav>

        {/* Mobile Toggle */}
        <button className="md:hidden" onClick={() => setMobileOpen(!mobileOpen)}>
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-md border-b">
          {NAV_ITEMS.map((item) => (
            <button
              key={item.href}
              onClick={() => { scrollTo(item.href); setMobileOpen(false); }}
              className="block w-full text-left px-6 py-3 text-sm hover:bg-gray-50"
            >
              {item.label}
            </button>
          ))}
        </div>
      )}
    </header>
  );
}
```

## 2. Hero（英雄区 + 粒子动画）

```tsx
// src/components/Hero.tsx
import { useEffect, useRef } from "react";
import { ArrowDown } from "lucide-react";

export default function Hero() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = window.innerWidth;
    let h = window.innerHeight;
    canvas.width = w;
    canvas.height = h;

    const particles: { x: number; y: number; vx: number; vy: number }[] = [];
    const COUNT = Math.min(80, Math.floor(w / 15));

    for (let i = 0; i < COUNT; i++) {
      particles.push({
        x: Math.random() * w,
        y: Math.random() * h,
        vx: (Math.random() - 0.5) * 0.5,
        vy: (Math.random() - 0.5) * 0.5,
      });
    }

    let mouse = { x: -9999, y: -9999 };
    const onMove = (e: MouseEvent) => { mouse = { x: e.clientX, y: e.clientY }; };
    window.addEventListener("mousemove", onMove);

    let raf: number;
    const animate = () => {
      ctx.clearRect(0, 0, w, h);

      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;
        if (p.x < 0) p.x = w;
        if (p.x > w) p.x = 0;
        if (p.y < 0) p.y = h;
        if (p.y > h) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, 2, 0, Math.PI * 2);
        ctx.fillStyle = "rgba(0, 229, 255, 0.6)";
        ctx.fill();
      });

      // 连线
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 120) {
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.strokeStyle = `rgba(0, 229, 255, ${0.15 * (1 - dist / 120)})`;
            ctx.lineWidth = 0.5;
            ctx.stroke();
          }
        }
      }

      // 鼠标连线
      particles.forEach((p) => {
        const dx = p.x - mouse.x;
        const dy = p.y - mouse.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 150) {
          ctx.beginPath();
          ctx.moveTo(p.x, p.y);
          ctx.lineTo(mouse.x, mouse.y);
          ctx.strokeStyle = `rgba(0, 229, 255, ${0.3 * (1 - dist / 150)})`;
          ctx.lineWidth = 0.8;
          ctx.stroke();
        }
      });

      raf = requestAnimationFrame(animate);
    };
    animate();

    const onResize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w;
      canvas.height = h;
    };
    window.addEventListener("resize", onResize);

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("resize", onResize);
    };
  }, []);

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <canvas ref={canvasRef} className="absolute inset-0" />
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-4xl md:text-6xl font-bold mb-6 gradient-text">
          企业标语 / Slogan
        </h1>
        <p className="text-lg md:text-xl text-foreground/70 mb-8 max-w-2xl mx-auto">
          一句话描述企业核心价值主张，让访客3秒内理解你是做什么的。
        </p>
        <div className="flex gap-4 justify-center">
          <button
            onClick={() => document.getElementById("contact")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3 bg-primary text-primary-foreground rounded-full font-medium hover:opacity-90 transition-opacity"
          >
            联系我们
          </button>
          <button
            onClick={() => document.getElementById("about")?.scrollIntoView({ behavior: "smooth" })}
            className="px-8 py-3 border border-primary/30 text-primary rounded-full font-medium hover:bg-primary/10 transition-colors"
          >
            了解更多
          </button>
        </div>
      </div>
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-primary/50" />
      </div>
    </section>
  );
}
```

## 3. About（关于我们 + 时间轴 + 统计）

```tsx
// src/components/About.tsx
import { useRef } from "react";
import { useInView } from "motion/react";

const TIMELINE = [
  { year: "2010", title: "公司成立", desc: "在某地创立，开始从事XXX业务。" },
  { year: "2015", title: "业务扩展", desc: "拓展到全国市场，团队规模达到50人。" },
  { year: "2020", title: "技术突破", desc: "自主研发核心平台，获得多项专利。" },
  { year: "2024", title: "战略升级", desc: "进军AI领域，启动国际化布局。" },
];

const STATS = [
  { value: "100+", label: "服务客户" },
  { value: "50+", label: "技术团队" },
  { value: "10年", label: "行业经验" },
  { value: "99%", label: "客户满意度" },
];

export default function About() {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-24 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        {/* Section Title */}
        <div ref={ref} className={`text-center mb-16 transition-all duration-700 ${isInView ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <h2 className="text-3xl md:text-4xl font-bold mb-4">关于我们</h2>
          <p className="text-foreground/60 max-w-2xl mx-auto">
            企业简介文字，描述公司使命、愿景和核心价值观。
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-20">
          {STATS.map((stat, i) => (
            <div key={stat.label} className="text-center p-6 rounded-xl border bg-card">
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div className="relative">
          <div className="absolute left-4 md:left-1/2 md:-translate-x-px top-0 bottom-0 w-0.5 bg-border" />
          {TIMELINE.map((item, i) => (
            <div key={item.year} className={`relative flex items-center mb-12 ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
              <div className="hidden md:block w-1/2 px-8 text-right">
                {i % 2 === 0 && (
                  <>
                    <div className="text-xl font-bold text-primary">{item.year}</div>
                    <div className="text-lg font-semibold mt-1">{item.title}</div>
                    <p className="text-sm text-muted-foreground mt-2">{item.desc}</p>
                  </>
                )}
              </div>
              <div className="absolute left-4 md:left-1/2 w-3 h-3 bg-primary rounded-full -translate-x-1.5" />
              <div className="ml-12 md:ml-0 md:w-1/2 md:px-8">
                <div className="md:hidden text-xl font-bold text-primary">{item.year}</div>
                <div className="text-lg font-semibold mt-1">{item.title}</div>
                <p className="text-sm text-muted-foreground mt-2">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

## 4. Business（业务领域 - 手风琴卡片）

```tsx
// src/components/Business.tsx
import { useState } from "react";
import { ChevronDown } from "lucide-react";

const BUSINESSES = [
  {
    id: "b1",
    title: "核心业务一",
    summary: "一句话概括业务价值。",
    detail: "详细描述业务内容、技术优势、应用场景和客户案例。可以包含列表、数据等。",
    icon: "🏢",
  },
  {
    id: "b2",
    title: "核心业务二",
    summary: "一句话概括业务价值。",
    detail: "详细描述...",
    icon: "🚀",
  },
  {
    id: "b3",
    title: "核心业务三",
    summary: "一句话概括业务价值。",
    detail: "详细描述...",
    icon: "💡",
  },
];

export default function Business() {
  const [openId, setOpenId] = useState<string | null>(null);

  return (
    <section id="business" className="py-24 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">业务领域</h2>
          <p className="text-foreground/60 max-w-2xl mx-auto">
            我们专注以下核心业务领域，为客户提供全方位解决方案。
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {BUSINESSES.map((biz) => (
            <div
              key={biz.id}
              className={`rounded-xl border bg-card p-6 cursor-pointer transition-all duration-300 ${
                openId === biz.id ? "ring-2 ring-primary" : "hover:shadow-lg"
              }`}
              onClick={() => setOpenId(openId === biz.id ? null : biz.id)}
            >
              <div className="text-4xl mb-4">{biz.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{biz.title}</h3>
              <p className="text-sm text-muted-foreground mb-4">{biz.summary}</p>

              <div className={`overflow-hidden transition-all duration-300 ${openId === biz.id ? "max-h-96 opacity-100" : "max-h-0 opacity-0"}`}>
                <p className="text-sm text-foreground/80 pt-4 border-t">{biz.detail}</p>
              </div>

              <div className="flex items-center justify-center mt-4 text-primary">
                <ChevronDown className={`w-5 h-5 transition-transform ${openId === biz.id ? "rotate-180" : ""}`} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
```

## 5. Contact（留言表单 + Supabase）

```tsx
// src/components/Contact.tsx
import { useState } from "react";
import { toast } from "sonner";
import { Send, Mail, Phone, MapPin } from "lucide-react";

// 如果使用 Supabase，取消注释：
// import { supabase } from "@/db/supabase";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", phone: "", company: "", message: "" });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name || !form.message) {
      toast.error("请填写必填项");
      return;
    }
    setSubmitting(true);

    // 方式1：保存到 Supabase（推荐）
    // const { error } = await supabase.from("messages").insert({
    //   name: form.name,
    //   email: form.email,
    //   phone: form.phone,
    //   company: form.company,
    //   message: form.message,
    // });

    // 方式2：发送到后端 API
    // await fetch("/api/contact", { method: "POST", body: JSON.stringify(form) });

    // 模拟提交
    await new Promise((r) => setTimeout(r, 1000));

    toast.success("提交成功！我们会尽快与您联系");
    setForm({ name: "", email: "", phone: "", company: "", message: "" });
    setSubmitting(false);
  };

  return (
    <section id="contact" className="py-24 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">联系我们</h2>
          <p className="text-foreground/60">期待与您的合作</p>
        </div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* 联系信息 */}
          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <MapPin className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <div className="font-medium">公司地址</div>
                <div className="text-sm text-muted-foreground">北京市朝阳区XXX路XXX号</div>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Phone className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <div className="font-medium">联系电话</div>
                <div className="text-sm text-muted-foreground">400-XXX-XXXX</div>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Mail className="w-5 h-5 text-primary mt-0.5" />
              <div>
                <div className="font-medium">电子邮箱</div>
                <div className="text-sm text-muted-foreground">contact@company.com</div>
              </div>
            </div>
          </div>

          {/* 表单 */}
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="姓名 *"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="px-4 py-3 rounded-lg border bg-card text-sm outline-none focus:ring-2 focus:ring-primary/30"
              />
              <input
                type="email"
                placeholder="邮箱"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="px-4 py-3 rounded-lg border bg-card text-sm outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <input
                type="tel"
                placeholder="电话"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })}
                className="px-4 py-3 rounded-lg border bg-card text-sm outline-none focus:ring-2 focus:ring-primary/30"
              />
              <input
                type="text"
                placeholder="公司名称"
                value={form.company}
                onChange={(e) => setForm({ ...form, company: e.target.value })}
                className="px-4 py-3 rounded-lg border bg-card text-sm outline-none focus:ring-2 focus:ring-primary/30"
              />
            </div>
            <textarea
              placeholder="留言内容 *"
              rows={4}
              value={form.message}
              onChange={(e) => setForm({ ...form, message: e.target.value })}
              className="w-full px-4 py-3 rounded-lg border bg-card text-sm outline-none focus:ring-2 focus:ring-primary/30 resize-none"
            />
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 bg-primary text-primary-foreground rounded-lg font-medium flex items-center justify-center gap-2 hover:opacity-90 disabled:opacity-50"
            >
              <Send className="w-4 h-4" />
              {submitting ? "提交中..." : "提交留言"}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
```

## 6. Footer（页脚）

```tsx
// src/components/Footer.tsx
export default function Footer() {
  return (
    <footer className="border-t py-8 px-4 md:px-8">
      <div className="max-w-6xl mx-auto">
        <div className="flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <img src="/logo.png" alt="Logo" className="w-6 h-6 rounded-full" />
            <span>企业名称 © {new Date().getFullYear()}</span>
          </div>
          <div className="flex gap-6">
            <a href="#" className="hover:text-foreground transition-colors">隐私政策</a>
            <a href="#" className="hover:text-foreground transition-colors">服务条款</a>
          </div>
          <div>京ICP备XXXXXXXX号</div>
        </div>
      </div>
    </footer>
  );
}
```
